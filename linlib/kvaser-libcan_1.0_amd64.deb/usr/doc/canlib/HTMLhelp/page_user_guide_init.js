var page_user_guide_init =
[
    [ "Library Initialization", "page_user_guide_init_lib_init.html", null ],
    [ "Library Deinitialization and Cleanup", "page_user_guide_init_lib_deinit.html", null ],
    [ "Chips and Channels", "page_user_guide_init_sel_channel.html", null ],
    [ "Bit Rate and Other Bus Parameters", "page_user_guide_init_bit_rate.html", null ],
    [ "CAN Driver Modes", "page_user_guide_init_driver_modes.html", null ]
];