var group___named_parameter_settings =
[
    [ "canParamGetCount", "group___named_parameter_settings.html#ga9df755f19415d207fe39ddf7df05a8b2", null ],
    [ "canParamCommitChanges", "group___named_parameter_settings.html#ga13c706cfc1d2c1931c5be0dd6f8644a4", null ],
    [ "canParamDeleteEntry", "group___named_parameter_settings.html#ga85d196e14288ad14e614d1d293afcd32", null ],
    [ "canParamCreateNewEntry", "group___named_parameter_settings.html#ga32f6a473bdab40c8bf971a5d80beedd2", null ],
    [ "canParamSwapEntries", "group___named_parameter_settings.html#gaa4e7c274507842195ee77d1a99afbd43", null ],
    [ "canParamGetName", "group___named_parameter_settings.html#gabce99362019fec8fd7062a567d9e42a8", null ],
    [ "canParamGetChannelNumber", "group___named_parameter_settings.html#gae6641f5c024ad0356ed535d5070c21c8", null ],
    [ "canParamGetBusParams", "group___named_parameter_settings.html#ga7f8bd035f474d325b904451f6575d2c2", null ],
    [ "canParamSetName", "group___named_parameter_settings.html#ga58cddc825e786fda9e19a8fd8b5879ca", null ],
    [ "canParamSetChannelNumber", "group___named_parameter_settings.html#ga97cc06366f6a918fe864ab59f0fcb2b0", null ],
    [ "canParamSetBusParams", "group___named_parameter_settings.html#ga7ef8f8128ca946e03a1bd3e17e9315fb", null ],
    [ "canParamFindByName", "group___named_parameter_settings.html#ga91886cded87a59bf550cb6697bf5a45e", null ]
];