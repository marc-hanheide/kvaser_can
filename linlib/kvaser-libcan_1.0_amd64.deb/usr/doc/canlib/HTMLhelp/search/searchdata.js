var indexSectionsWithContent =
{
  0: "abcdefghijklmnoprstuvwz",
  1: "cjklt",
  2: "cjklo",
  3: "cjkl",
  4: "abcdefimnoprstvz",
  5: "cjkl",
  6: "cjkl",
  7: "cjkl",
  8: "bcejklw",
  9: "cgjlnot",
  10: "abcdfghilmnoprstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

