var searchData=
[
  ['named_20parameter_20sets',['Named Parameter Sets',['../page_user_guide_misc_named_parameters.html',1,'page_user_guide_misc']]]
];
