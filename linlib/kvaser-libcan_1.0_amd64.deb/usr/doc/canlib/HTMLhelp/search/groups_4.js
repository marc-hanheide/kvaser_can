var searchData=
[
  ['named_20parameter_20settings',['Named Parameter Settings',['../group___named_parameter_settings.html',1,'']]]
];
