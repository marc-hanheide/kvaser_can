var searchData=
[
  ['linstatus',['LinStatus',['../linlib_8h.html#a7a5ecfd2846ddd76cd49fb4edec7fc14',1,'linlib.h']]]
];
