var searchData=
[
  ['errframe',['errFrame',['../structcan_bus_statistics__s.html#a54171b8fd05e42011ec548693594b4c5',1,'canBusStatistics_s']]],
  ['extdata',['extData',['../structcan_bus_statistics__s.html#ad071e3666d2aedd0e3c971a3b4148385',1,'canBusStatistics_s']]],
  ['extremote',['extRemote',['../structcan_bus_statistics__s.html#a14481e6fd492f4db9a7db4062d5fc199',1,'canBusStatistics_s']]]
];
