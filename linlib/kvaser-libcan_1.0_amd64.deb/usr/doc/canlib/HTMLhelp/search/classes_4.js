var searchData=
[
  ['tagcanhwdescr',['tagCanHWDescr',['../structtag_can_h_w_descr.html',1,'']]],
  ['tagcanswdescr',['tagCanSWDescr',['../structtag_can_s_w_descr.html',1,'']]]
];
