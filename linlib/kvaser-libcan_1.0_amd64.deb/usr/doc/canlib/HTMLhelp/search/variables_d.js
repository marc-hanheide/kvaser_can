var searchData=
[
  ['timestamp',['timestamp',['../struct_lin_message_info.html#acba7776dcc1861edfe0e9c5736de4df8',1,'LinMessageInfo::timestamp()'],['../struct_j1587_message_info.html#acba7776dcc1861edfe0e9c5736de4df8',1,'J1587MessageInfo::timestamp()']]],
  ['txbufsize',['txBufSize',['../structtag_can_s_w_descr.html#a4f409383284eb558a8b4c97e46155799',1,'tagCanSWDescr']]]
];
