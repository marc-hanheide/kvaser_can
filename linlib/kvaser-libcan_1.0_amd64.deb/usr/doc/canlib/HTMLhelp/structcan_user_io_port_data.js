var structcan_user_io_port_data =
[
    [ "portNo", "structcan_user_io_port_data.html#a3001cfa2429ae1926b29f0d14e7184e0", null ],
    [ "portValue", "structcan_user_io_port_data.html#acd5ef299b011d43a09b0f97f96edd444", null ]
];