var annotated_dup =
[
    [ "canBusStatistics_s", "structcan_bus_statistics__s.html", "structcan_bus_statistics__s" ],
    [ "canUserIoPortData", "structcan_user_io_port_data.html", "structcan_user_io_port_data" ],
    [ "J1587MessageInfo", "struct_j1587_message_info.html", "struct_j1587_message_info" ],
    [ "KvaDbProtocolProperties", "struct_kva_db_protocol_properties.html", "struct_kva_db_protocol_properties" ],
    [ "kvTimeDomainData_s", "structkv_time_domain_data__s.html", "structkv_time_domain_data__s" ],
    [ "LinMessageInfo", "struct_lin_message_info.html", "struct_lin_message_info" ],
    [ "tagCanHWDescr", "structtag_can_h_w_descr.html", "structtag_can_h_w_descr" ],
    [ "tagCanSWDescr", "structtag_can_s_w_descr.html", "structtag_can_s_w_descr" ]
];