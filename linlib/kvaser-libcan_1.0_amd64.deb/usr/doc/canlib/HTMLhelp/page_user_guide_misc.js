var page_user_guide_misc =
[
    [ "Named Parameter Sets", "page_user_guide_misc_named_parameters.html", null ],
    [ "Message Flags", "page_user_guide_misc_message_flags.html", null ],
    [ "Bit Rate Constants", "page_user_guide_misc_bitrate.html", null ],
    [ "Code and Mask Format", "page_user_guide_misc_code_and_mask.html", null ]
];